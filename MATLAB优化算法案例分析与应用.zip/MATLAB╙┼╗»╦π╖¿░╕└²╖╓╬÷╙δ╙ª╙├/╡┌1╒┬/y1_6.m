%%
Digit_Ma = [1/3  sqrt(3) 3.1;exp(0.3) log(10) 23^.5]
Syms_Ma = sym(Digit_Ma)
