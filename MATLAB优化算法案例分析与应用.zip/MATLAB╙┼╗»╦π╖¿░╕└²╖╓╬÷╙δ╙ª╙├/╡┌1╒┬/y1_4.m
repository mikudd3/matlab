%%
sym_m = sym('[a b c;Jack,Help Me!,NO WAY!]')
sym_d = sym('[1 2 3;a b c;sin(x) cos(y) tan(z)]')