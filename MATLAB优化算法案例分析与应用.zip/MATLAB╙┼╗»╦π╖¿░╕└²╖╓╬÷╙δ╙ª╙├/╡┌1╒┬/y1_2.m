%%
a=1.7;b=3/25;
C=[1,3*a+i*b,b*sqrt(a); sin(pi/5),a+7*b,3.9+1]
