%%
syms  a  b  c 
M1 = sym('Classical');
M2 = sym('Claysw');
M3 = sym('yellow');
yswM123=[a,b,c;M1,M2,M3;2,3,5;5,4,6]
